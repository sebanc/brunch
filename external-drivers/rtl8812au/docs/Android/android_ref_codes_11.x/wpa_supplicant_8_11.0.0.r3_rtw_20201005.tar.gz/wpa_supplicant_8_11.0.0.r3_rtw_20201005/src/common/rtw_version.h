#ifndef RTW_VERSION_H
	#define RTW_VERSION_H
	#define RTW_VERSION "rtw_11.0.0.r3_20201005"
#endif /* RTW_VERSION_H */
