#ifndef VERSION_H
#define VERSION_H

#define RTW_WIFI_HAL_VERSION "v1.0.4"

#endif /* VERSION_H */
