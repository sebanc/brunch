#ifndef RTW_VERSION_H
	#define RTW_VERSION_H
	#define RTW_VERSION "rtw_r24600.20171025"
#endif /* RTW_VERSION_H */
